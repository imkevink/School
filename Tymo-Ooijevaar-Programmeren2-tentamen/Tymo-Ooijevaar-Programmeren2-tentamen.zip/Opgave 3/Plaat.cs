﻿namespace Opgave_3
{
    public class Plaat
    {
        public int ranking;
        public string titel;
        public string artiest;
        public int jaar;
    }
}
