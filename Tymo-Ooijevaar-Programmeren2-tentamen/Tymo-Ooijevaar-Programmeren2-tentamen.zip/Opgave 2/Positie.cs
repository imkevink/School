﻿namespace Opgave_2
{
    public class Positie
    {
        public int rij;
        public int kolom;
        public int waarde;
    }
}
